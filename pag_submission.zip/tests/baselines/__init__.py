"""Baseline stage tests."""
