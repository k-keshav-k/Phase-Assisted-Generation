"""Phase stage tests."""
