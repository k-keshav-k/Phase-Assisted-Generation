"""Scheduler stage tests."""
