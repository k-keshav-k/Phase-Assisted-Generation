"""LLaDA integration tests."""
