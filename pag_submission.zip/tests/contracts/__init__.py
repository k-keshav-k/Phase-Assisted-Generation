"""Contracts test package."""
