from __future__ import annotations

import csv
import json
from collections.abc import Mapping, Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np

from pag.experiments.statistics import pair_records, paired_bootstrap, wilson_interval

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

_MODELS = ("llada", "dream")
_DATASETS = ("gsm8k_test", "math500", "mbpp_sanitized", "humaneval")
_IN_DOMAIN = _DATASETS[:3]
_DEFAULT_METHODS = ("adablock", "best_nonlearned", "rc_pag_local", "rc_pag_history")


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _is_correct(row: Mapping[str, Any]) -> bool:
    grade = row.get("grade")
    if isinstance(grade, Mapping):
        return bool(grade.get("is_correct"))
    if "is_correct" not in row:
        raise ValueError("confirmatory record is missing is_correct")
    return bool(row["is_correct"])


def _summary(rows: Sequence[Mapping[str, Any]]) -> dict[str, object]:
    if not rows:
        raise ValueError("cannot report an empty method")
    correctness = [_is_correct(row) for row in rows]
    nfe = np.asarray([float(row["total_nfe"]) for row in rows], dtype=np.float64)
    latency = np.asarray([float(row["elapsed_sec"]) for row in rows], dtype=np.float64)
    serial_calls = np.asarray(
        [float(row.get("serial_forward_calls", row["total_nfe"])) for row in rows],
        dtype=np.float64,
    )
    evaluated_rows = np.asarray(
        [float(row.get("evaluated_rows", row["total_nfe"])) for row in rows],
        dtype=np.float64,
    )
    model_time = np.asarray(
        [float(row.get("model_time_sec", row["elapsed_sec"])) for row in rows],
        dtype=np.float64,
    )
    speculation_steps = [
        step
        for row in rows
        for block in row.get("schedule_history", ())
        for step in block.get("speculation_steps", ())
    ]
    speculation = None
    if speculation_steps:
        accepted = sum(int(step["accepted_draft_edges"]) for step in speculation_steps)
        offered = sum(max(0, int(step["evaluated_nodes"]) - 1) for step in speculation_steps)
        speculation = {
            "rounds": len(speculation_steps),
            "mean_nodes_per_round": float(
                np.mean([float(step["evaluated_nodes"]) for step in speculation_steps])
            ),
            "mean_verified_transitions_per_round": float(
                np.mean([float(step["verified_transitions"]) for step in speculation_steps])
            ),
            "draft_edge_acceptance": accepted / offered if offered else 0.0,
            "reported_nfe_saved": sum(int(step["nfe_saved"]) for step in speculation_steps),
            "guard_passes": sum(bool(step.get("guard_passed")) for step in speculation_steps),
            "reference_checks": sum(
                bool(step.get("reference_checked")) for step in speculation_steps
            ),
            "canonical_fallback_rows": sum(
                int(step.get("canonical_fallback_rows", 0)) for step in speculation_steps
            ),
            "guard_evidence_complete": all(
                bool(step.get("guard_passed")) or bool(step.get("reference_checked"))
                for step in speculation_steps
            ),
        }
    return {
        "count": len(rows),
        "correct": sum(correctness),
        "accuracy": asdict(wilson_interval(sum(correctness), len(rows))),
        "mean_nfe": float(np.mean(nfe)),
        "median_nfe": float(np.median(nfe)),
        "mean_latency_sec": float(np.mean(latency)),
        "median_latency_sec": float(np.median(latency)),
        "mean_serial_forward_calls": float(np.mean(serial_calls)),
        "mean_evaluated_rows": float(np.mean(evaluated_rows)),
        "mean_model_time_sec": float(np.mean(model_time)),
        "speculation": speculation,
    }


def _pair_summary(
    candidate: Sequence[dict[str, Any]],
    baseline: Sequence[dict[str, Any]],
    *,
    bootstrap_samples: int,
    seed: int,
) -> dict[str, object]:
    pairs = pair_records(candidate, baseline)
    candidate_nfe = [float(left["total_nfe"]) for left, _ in pairs]
    baseline_nfe = [float(right["total_nfe"]) for _, right in pairs]
    candidate_accuracy = [float(_is_correct(left)) for left, _ in pairs]
    baseline_accuracy = [float(_is_correct(right)) for _, right in pairs]
    candidate_latency = [float(left["elapsed_sec"]) for left, _ in pairs]
    baseline_latency = [float(right["elapsed_sec"]) for _, right in pairs]
    candidate_model_time = [
        float(left.get("model_time_sec", left["elapsed_sec"])) for left, _ in pairs
    ]
    baseline_model_time = [
        float(right.get("model_time_sec", right["elapsed_sec"])) for _, right in pairs
    ]
    candidate_rows = [float(left.get("evaluated_rows", left["total_nfe"])) for left, _ in pairs]
    baseline_rows = [float(right.get("evaluated_rows", right["total_nfe"])) for _, right in pairs]
    harmful_regressions = sum(
        _is_correct(reference) and not _is_correct(policy) for policy, reference in pairs
    )
    beneficial_changes = sum(
        not _is_correct(reference) and _is_correct(policy) for policy, reference in pairs
    )
    sequence_disagreements = sum(
        policy.get("generated_ids") != reference.get("generated_ids")
        for policy, reference in pairs
        if "generated_ids" in policy and "generated_ids" in reference
    )
    trajectory_disagreements = sum(
        policy.get("state_trajectory_digest") != reference.get("state_trajectory_digest")
        for policy, reference in pairs
        if "state_trajectory_digest" in policy and "state_trajectory_digest" in reference
    )
    nfe = paired_bootstrap(
        candidate_nfe,
        baseline_nfe,
        samples=bootstrap_samples,
        seed=seed,
    )
    latency_difference = paired_bootstrap(
        candidate_latency,
        baseline_latency,
        samples=bootstrap_samples,
        seed=seed + 2,
    )
    model_time_difference = paired_bootstrap(
        candidate_model_time,
        baseline_model_time,
        samples=bootstrap_samples,
        seed=seed + 3,
    )
    evaluated_row_difference = paired_bootstrap(
        candidate_rows,
        baseline_rows,
        samples=bootstrap_samples,
        seed=seed + 4,
    )
    return {
        "count": len(pairs),
        "harmful_regressions": harmful_regressions,
        "beneficial_changes": beneficial_changes,
        "sequence_disagreements": sequence_disagreements,
        "trajectory_disagreements": trajectory_disagreements,
        "nfe_difference": asdict(nfe),
        "nfe_reduction": -nfe.estimate / float(np.mean(baseline_nfe)),
        "accuracy_difference": asdict(
            paired_bootstrap(
                candidate_accuracy,
                baseline_accuracy,
                samples=bootstrap_samples,
                seed=seed + 1,
            )
        ),
        "latency_difference": asdict(latency_difference),
        "latency_reduction": (-latency_difference.estimate / float(np.mean(baseline_latency))),
        "model_time_difference": asdict(model_time_difference),
        "model_time_reduction": (
            -model_time_difference.estimate / float(np.mean(baseline_model_time))
        ),
        "evaluated_row_difference": asdict(evaluated_row_difference),
        "evaluated_row_nonincrease": float(np.sum(candidate_rows)) <= float(np.sum(baseline_rows)),
    }


def _validate_coverage(
    records: Mapping[str, Mapping[str, Mapping[str, Sequence[dict[str, Any]]]]],
    expected_methods: Sequence[str],
) -> None:
    if set(records) != set(_MODELS):
        raise ValueError("report coverage must contain exactly LLaDA and Dream")
    for model in _MODELS:
        if set(records[model]) != set(_DATASETS):
            raise ValueError(f"report coverage is incomplete for {model}")
        for dataset in _DATASETS:
            methods = records[model][dataset]
            if set(methods) != set(expected_methods):
                raise ValueError(f"method coverage is incomplete for {model}/{dataset}")
            id_sets = [
                {str(row["sample_id"]) for row in methods[method]} for method in expected_methods
            ]
            if not id_sets[0] or any(ids != id_sets[0] for ids in id_sets[1:]):
                raise ValueError(f"paired coverage is incomplete for {model}/{dataset}")


def _risk_rows(certificate: Mapping[str, Any]) -> list[dict[str, Any]]:
    required = {
        "name",
        "failures",
        "count",
        "empirical_risk",
        "upper_risk_bound",
        "pvalue",
        "corrected_cutoff",
        "certified",
        "mean_nfe",
    }
    joint_required = {
        "harm_pvalue",
        "compute_pvalue",
        "harm_certified",
        "compute_certified",
        "empirical_nfe_reduction",
        "lower_nfe_reduction_bound",
    }
    if certificate.get("minimum_nfe_reduction") is not None:
        required |= joint_required
    values = []
    for candidate in certificate.get("candidates", ()):
        row = dict(candidate)
        if not required.issubset(row):
            raise ValueError("risk certificate candidate is incomplete")
        values.append(row)
    if not values:
        raise ValueError("risk certificate has no candidate audits")
    return values


def _selected_risk(
    risk_rows: Sequence[Mapping[str, Any]], token: str, *, model: str
) -> Mapping[str, Any] | None:
    prefix = f"{model}/"
    eligible = [
        row
        for row in risk_rows
        if str(row["name"]).startswith(prefix)
        and token in str(row["name"])
        and bool(row["certified"])
    ]
    return (
        min(eligible, key=lambda row: (float(row["mean_nfe"]), str(row["name"])))
        if eligible
        else None
    )


def _audit(
    summary: Mapping[str, Any],
    certificate: Mapping[str, Any],
    *,
    minimum_accuracy_lower_ci: float,
    bootstrap_samples: int,
    seed: int,
    records: Mapping[str, Mapping[str, Mapping[str, Sequence[dict[str, Any]]]]],
    primary_method: str,
    require_history_frontier_ci: bool,
    minimum_model_nfe_reduction_lower_ci: float | None,
    minimum_model_latency_reduction_lower_ci: float | None,
    require_evaluated_row_nonincrease: bool,
    require_trajectory_equivalence: bool,
) -> dict[str, Any]:
    risk_rows = _risk_rows(certificate)
    selected_risks: dict[tuple[str, str], Mapping[str, Any] | None]
    if primary_method == "rc_pag_selected":
        frozen_names = certificate.get("selected_by_model", {})
        selected_risks = {
            (model, "selected"): next(
                (
                    row
                    for row in risk_rows
                    if row["name"] == f"{model}/{frozen_names.get(model, '')}"
                    and bool(row["certified"])
                ),
                None,
            )
            for model in _MODELS
        }
    else:
        selected_risks = {
            (model, variant): _selected_risk(risk_rows, variant, model=model)
            for model in _MODELS
            for variant in ("local", "history")
        }
    risk_ok = not bool(certificate.get("fallback", True)) and all(
        selected is not None for selected in selected_risks.values()
    )
    if certificate.get("certificate_mode") == "hardware_scoped_execution_equivalence":
        required_latency = minimum_model_latency_reduction_lower_ci
        if required_latency is None:
            raise ValueError("v9 reporting requires a model-level latency threshold")
        sequence_disagreements = {
            f"{model}/{dataset}": int(
                summary[model][dataset]["comparisons"][f"{primary_method}_vs_adablock"][
                    "sequence_disagreements"
                ]
            )
            for model in _MODELS
            for dataset in _DATASETS
        }
        trajectory_disagreements = {
            f"{model}/{dataset}": int(
                summary[model][dataset]["comparisons"][f"{primary_method}_vs_adablock"][
                    "trajectory_disagreements"
                ]
            )
            for model in _MODELS
            for dataset in _DATASETS
        }
        accuracy_lowers = [
            float(
                summary[model][dataset]["comparisons"][f"{primary_method}_vs_adablock"][
                    "accuracy_difference"
                ]["lower"]
            )
            for model in _MODELS
            for dataset in _DATASETS
        ]
        model_latency: dict[str, dict[str, float]] = {}
        model_time: dict[str, dict[str, float]] = {}
        evaluated_rows: dict[str, dict[str, float | bool]] = {}
        for model_index, model in enumerate(_MODELS):
            candidate_latency: list[float] = []
            baseline_latency: list[float] = []
            candidate_model_time: list[float] = []
            baseline_model_time: list[float] = []
            candidate_work = 0.0
            baseline_work = 0.0
            for dataset in _DATASETS:
                pairs = pair_records(
                    records[model][dataset][primary_method],
                    records[model][dataset]["adablock"],
                )
                candidate_work += sum(
                    float(left.get("evaluated_rows", left["total_nfe"])) for left, _ in pairs
                )
                baseline_work += sum(
                    float(right.get("evaluated_rows", right["total_nfe"])) for _, right in pairs
                )
                if dataset not in _IN_DOMAIN:
                    continue
                candidate_latency.extend(float(left["elapsed_sec"]) for left, _ in pairs)
                baseline_latency.extend(float(right["elapsed_sec"]) for _, right in pairs)
                candidate_model_time.extend(
                    float(left.get("model_time_sec", left["elapsed_sec"])) for left, _ in pairs
                )
                baseline_model_time.extend(
                    float(right.get("model_time_sec", right["elapsed_sec"])) for _, right in pairs
                )
            latency_difference = paired_bootstrap(
                candidate_latency,
                baseline_latency,
                samples=bootstrap_samples,
                seed=seed + 501 + model_index,
            )
            model_difference = paired_bootstrap(
                candidate_model_time,
                baseline_model_time,
                samples=bootstrap_samples,
                seed=seed + 511 + model_index,
            )
            baseline_latency_mean = float(np.mean(baseline_latency))
            baseline_model_time_mean = float(np.mean(baseline_model_time))
            model_latency[model] = {
                "estimate": -latency_difference.estimate / baseline_latency_mean,
                "lower": -latency_difference.upper / baseline_latency_mean,
                "upper": -latency_difference.lower / baseline_latency_mean,
            }
            model_time[model] = {
                "estimate": -model_difference.estimate / baseline_model_time_mean,
                "lower": -model_difference.upper / baseline_model_time_mean,
                "upper": -model_difference.lower / baseline_model_time_mean,
            }
            evaluated_rows[model] = {
                "candidate": candidate_work,
                "adablock": baseline_work,
                "nonincrease": candidate_work <= baseline_work,
            }
        speculation_steps = [
            step
            for model in _MODELS
            for dataset in _DATASETS
            for row in records[model][dataset][primary_method]
            for block in row.get("schedule_history", ())
            for step in block.get("speculation_steps", ())
        ]
        complete_guard_evidence = bool(speculation_steps) and all(
            bool(step.get("guard_passed")) or bool(step.get("reference_checked"))
            for step in speculation_steps
        )
        gates = {
            "risk_certificate": risk_ok,
            "exact_sequence_equivalence": not any(sequence_disagreements.values()),
            "exact_trajectory_equivalence": (
                not require_trajectory_equivalence or not any(trajectory_disagreements.values())
            ),
            "accuracy_noninferiority": min(accuracy_lowers) >= minimum_accuracy_lower_ci,
            "model_latency_reduction_lower_ci": all(
                interval["lower"] > required_latency for interval in model_latency.values()
            ),
            "positive_model_time_reduction_lower_ci": all(
                interval["lower"] > 0.0 for interval in model_time.values()
            ),
            "evaluated_row_nonincrease": (
                not require_evaluated_row_nonincrease
                or all(bool(values["nonincrease"]) for values in evaluated_rows.values())
            ),
            "complete_guard_diagnostics": complete_guard_evidence,
            "non_mock_evidence": not bool(certificate.get("mock", False)),
        }
        failed = [name for name, passed in gates.items() if not passed]
        return {
            "headline_eligible": not failed,
            "failed_gates": failed,
            "gates": gates,
            "details": {
                "primary_method": primary_method,
                "sequence_disagreements": sequence_disagreements,
                "trajectory_disagreements": trajectory_disagreements,
                "minimum_accuracy_lower_ci": min(accuracy_lowers),
                "required_accuracy_lower_ci": minimum_accuracy_lower_ci,
                "model_latency_reduction": model_latency,
                "required_model_latency_reduction_lower_ci": required_latency,
                "model_time_reduction": model_time,
                "evaluated_rows": evaluated_rows,
                "guarded_speculation_rounds": len(speculation_steps),
            },
        }
    beat_adablock_models = {}
    for model in _MODELS:
        candidate_values = [
            float(row["total_nfe"])
            for dataset in _IN_DOMAIN
            for row in records[model][dataset][primary_method]
        ]
        baseline_values = [
            float(row["total_nfe"])
            for dataset in _IN_DOMAIN
            for row in records[model][dataset]["adablock"]
        ]
        beat_adablock_models[model] = float(np.mean(candidate_values)) < float(
            np.mean(baseline_values)
        )
    candidate_all = [
        float(row["total_nfe"])
        for model in _MODELS
        for dataset in _IN_DOMAIN
        for row in records[model][dataset][primary_method]
    ]
    heuristic_all = [
        float(row["total_nfe"])
        for model in _MODELS
        for dataset in _IN_DOMAIN
        for row in records[model][dataset]["best_nonlearned"]
    ]
    accuracy_lowers = [
        float(
            summary[model][dataset]["comparisons"][f"{primary_method}_vs_adablock"][
                "accuracy_difference"
            ]["lower"]
        )
        for model in _MODELS
        for dataset in _IN_DOMAIN
    ]
    gates = {
        "risk_certificate": risk_ok,
        "beat_adablock_both_models": all(beat_adablock_models.values()),
        "beat_best_nonlearned": float(np.mean(candidate_all)) < float(np.mean(heuristic_all)),
        "accuracy_noninferiority": min(accuracy_lowers) >= minimum_accuracy_lower_ci,
    }
    details: dict[str, Any] = {
        "primary_method": primary_method,
        "beat_adablock_models": beat_adablock_models,
        "minimum_accuracy_lower_ci": min(accuracy_lowers),
        "required_accuracy_lower_ci": minimum_accuracy_lower_ci,
        "history_frontier_required": require_history_frontier_ci,
    }
    if certificate.get("certificate_mode") == "exact_trajectory_with_paired_compute_evidence":
        disagreements = {
            f"{model}/{dataset}": int(
                summary[model][dataset]["comparisons"][f"{primary_method}_vs_adablock"][
                    "sequence_disagreements"
                ]
            )
            for model in _MODELS
            for dataset in _DATASETS
        }
        verifier_evidence = all(
            row.get("schedule_history")
            and all(
                bool(block.get("verified_sequence_safe", False))
                for block in row["schedule_history"]
            )
            for model in _MODELS
            for dataset in _DATASETS
            for row in records[model][dataset][primary_method]
        )
        gates["exact_sequence_equivalence"] = not any(disagreements.values())
        gates["verified_transition_evidence"] = verifier_evidence
        details["sequence_disagreements"] = disagreements
    if minimum_model_nfe_reduction_lower_ci is not None:
        model_compute: dict[str, dict[str, float]] = {}
        for model_index, model in enumerate(_MODELS):
            candidate_nfe: list[float] = []
            baseline_nfe: list[float] = []
            for dataset in _IN_DOMAIN:
                pairs = pair_records(
                    records[model][dataset][primary_method],
                    records[model][dataset]["adablock"],
                )
                candidate_nfe.extend(float(left["total_nfe"]) for left, _ in pairs)
                baseline_nfe.extend(float(right["total_nfe"]) for _, right in pairs)
            difference = paired_bootstrap(
                candidate_nfe,
                baseline_nfe,
                samples=bootstrap_samples,
                seed=seed + 71 + model_index,
            )
            baseline_mean = float(np.mean(baseline_nfe))
            model_compute[model] = {
                "estimate": -difference.estimate / baseline_mean,
                "lower": -difference.upper / baseline_mean,
                "upper": -difference.lower / baseline_mean,
            }
        gates["model_nfe_reduction_lower_ci"] = all(
            interval["lower"] > minimum_model_nfe_reduction_lower_ci
            for interval in model_compute.values()
        )
        details.update(
            {
                "model_nfe_reduction": model_compute,
                "required_model_nfe_reduction_lower_ci": (minimum_model_nfe_reduction_lower_ci),
            }
        )
    if require_history_frontier_ci:
        if any(
            "rc_pag_local" not in records[model][dataset]
            or "rc_pag_history" not in records[model][dataset]
            for model in _MODELS
            for dataset in _IN_DOMAIN
        ):
            raise ValueError("history frontier requires paired local and history records")
        history_nfe: list[float] = []
        local_nfe: list[float] = []
        for model in _MODELS:
            for dataset in _IN_DOMAIN:
                pairs = pair_records(
                    records[model][dataset]["rc_pag_history"],
                    records[model][dataset]["rc_pag_local"],
                )
                history_nfe.extend(float(left["total_nfe"]) for left, _ in pairs)
                local_nfe.extend(float(right["total_nfe"]) for _, right in pairs)
        history_interval = paired_bootstrap(
            history_nfe,
            local_nfe,
            samples=bootstrap_samples,
            seed=seed + 37,
        )
        history_risk_not_worse = all(
            selected_risks[(model, "local")] is not None
            and selected_risks[(model, "history")] is not None
            and float(selected_risks[(model, "history")]["empirical_risk"])
            <= float(selected_risks[(model, "local")]["empirical_risk"])
            for model in _MODELS
        )
        gates["history_frontier"] = history_interval.upper < 0 and history_risk_not_worse
        details.update(
            {
                "history_minus_local_nfe": asdict(history_interval),
                "history_risk_not_worse": history_risk_not_worse,
            }
        )
    if bool(certificate.get("mock", False)):
        gates["non_mock_evidence"] = False
    failed = [name for name, passed in gates.items() if not passed]
    return {
        "headline_eligible": not failed,
        "failed_gates": failed,
        "gates": gates,
        "details": details,
    }


def _latex_name(value: str) -> str:
    return value.replace("_", "\\_")


def _write_main_table(path: Path, summary: Mapping[str, Any], methods: Sequence[str]) -> None:
    lines = [
        "\\begin{tabular}{lllrr}",
        "\\toprule",
        "Model & Dataset & Method & Accuracy & Mean NFE \\\\",
        "\\midrule",
    ]
    for model in _MODELS:
        for dataset in _DATASETS:
            for method in methods:
                values = summary[model][dataset]["methods"][method]
                lines.append(
                    f"{_latex_name(model)} & {_latex_name(dataset)} & {_latex_name(method)} & "
                    f"{100 * values['accuracy']['estimate']:.1f} & {values['mean_nfe']:.2f} \\\\"
                )
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_calibration_table(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    joint = all(row.get("compute_pvalue") is not None for row in rows)
    if joint:
        lines = [
            "\\begin{tabular}{lrrrrrrrr}",
            "\\toprule",
            (
                "Candidate & Errors/$n$ & Risk & Risk UCB & $p_H$ & Saving & "
                "Saving LCB & $p_C$ & Joint \\\\"
            ),
            "\\midrule",
        ]
        for row in sorted(rows, key=lambda item: str(item["name"])):
            lines.append(
                f"{_latex_name(str(row['name']))} & {row['failures']}/{row['count']} & "
                f"{float(row['empirical_risk']):.3f} & {float(row['upper_risk_bound']):.3f} & "
                f"{float(row['harm_pvalue']):.4g} & "
                f"{100 * float(row['empirical_nfe_reduction']):.1f}\\% & "
                f"{100 * float(row['lower_nfe_reduction_bound']):.1f}\\% & "
                f"{float(row['compute_pvalue']):.4g} & "
                f"{'yes' if row['certified'] else 'no'} \\\\"
            )
        lines.extend(("\\bottomrule", "\\end{tabular}"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return
    lines = [
        "\\begin{tabular}{lrrrrr}",
        "\\toprule",
        "Candidate & Errors/$n$ & Risk & Upper & $p$ & Certified \\\\",
        "\\midrule",
    ]
    for row in sorted(rows, key=lambda item: str(item["name"])):
        lines.append(
            f"{_latex_name(str(row['name']))} & {row['failures']}/{row['count']} & "
            f"{float(row['empirical_risk']):.3f} & {float(row['upper_risk_bound']):.3f} & "
            f"{float(row['pvalue']):.4g} & {'yes' if row['certified'] else 'no'} \\\\"
        )
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_ablation_table(path: Path, summary: Mapping[str, Any], methods: Sequence[str]) -> None:
    aggregate = summary["normalized_cross_model"]
    lines = [
        "\\begin{tabular}{lrr}",
        "\\toprule",
        "Variant & Normalized NFE & $\\Delta$ vs. AdaBlock \\\\",
        "\\midrule",
    ]
    for method in methods:
        ratio = float(aggregate[method])
        lines.append(f"{_latex_name(method)} & {ratio:.3f} & {100 * (ratio - 1):+.1f}\\% \\\\ ")
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_estimator_table(path: Path, manifest: Mapping[str, Any]) -> None:
    lines = [
        "\\begin{tabular}{llllrr}",
        "\\toprule",
        "Model & Features & Estimator & Split & Brier & AUROC \\\\",
        "\\midrule",
    ]
    for model, variants in sorted(manifest.get("models", {}).items()):
        for variant, payload in sorted(variants.items()):
            for kind, estimator in sorted(payload["estimators"].items()):
                validation = estimator["validation"]
                auc = validation["roc_auc"]
                auc_text = "--" if auc is None else f"{float(auc):.3f}"
                split = "holdout" if "holdout" in validation["split"] else "small-run"
                lines.append(
                    f"{_latex_name(model)} & {_latex_name(variant)} & "
                    f"{_latex_name(kind)} & {split} & {float(validation['brier']):.3f} & "
                    f"{auc_text} \\\\"
                )
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_screening_table(path: Path, screening: Mapping[str, Any]) -> None:
    selected = screening.get("selected_candidate", {})
    models = screening.get("models", {})
    if not isinstance(selected, Mapping) or not isinstance(models, Mapping):
        raise ValueError("screening summary is missing per-model candidate results")
    lines = [
        "\\begin{tabular}{llrrrl}",
        "\\toprule",
        "Model & Candidate & Mean NFE & Correct & Harm & Status \\\\",
        "\\midrule",
    ]
    for model, payload in sorted(models.items()):
        candidates = payload.get("candidates", {})
        for name, stats in sorted(candidates.items()):
            status = (
                "selected"
                if selected.get(model) == name
                else ("eligible" if stats["accuracy_eligible"] else "rejected")
            )
            lines.append(
                f"{_latex_name(str(model))} & {_latex_name(str(name))} & "
                f"{float(stats['mean_nfe']):.2f} & {int(stats['correct'])} & "
                f"{int(stats['harmful_regressions'])} & {status} \\\\"
            )
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_benefit_table(path: Path, manifest: Mapping[str, Any]) -> None:
    models = manifest.get("benefit_models", {})
    if not models:
        return
    lines = [
        "\\begin{tabular}{llllrr}",
        "\\toprule",
        "Model & Target & Source & Split & MAE & RMSE \\\\ ",
        "\\midrule",
    ]
    for model, payload in sorted(models.items()):
        validation = payload["validation"]
        split = "holdout" if "holdout" in validation["split"] else "small-run"
        lines.append(
            f"{_latex_name(str(model))} & remaining NFE & "
            f"{_latex_name(str(payload['source']))} & {split} & "
            f"{float(validation['mae']):.2f} & {float(validation['rmse']):.2f} \\\\"
        )
    lines.extend(("\\bottomrule", "\\end{tabular}"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_figures(
    output: Path,
    summary: Mapping[str, Any],
    risk_rows: Sequence[Mapping[str, Any]],
    methods: Sequence[str],
    *,
    alpha: float,
) -> None:
    figure, axis = plt.subplots(figsize=(6.2, 4.0))
    markers = {"llada": "o", "dream": "s"}
    for model in _MODELS:
        for method in methods:
            nfe = np.mean(
                [summary[model][dataset]["methods"][method]["mean_nfe"] for dataset in _IN_DOMAIN]
            )
            accuracy = np.mean(
                [
                    summary[model][dataset]["methods"][method]["accuracy"]["estimate"]
                    for dataset in _IN_DOMAIN
                ]
            )
            axis.scatter(nfe, accuracy, marker=markers[model], s=38)
            axis.annotate(f"{model}:{method}", (nfe, accuracy), fontsize=6)
    axis.set_xlabel("Mean NFE (lower is better)")
    axis.set_ylabel("Accuracy")
    figure.tight_layout()
    figure.savefig(output / "nfe_accuracy.pdf")
    plt.close(figure)

    names = [str(row["name"]) for row in risk_rows]
    nfe = [float(row["mean_nfe"]) for row in risk_rows]
    risks = [float(row["empirical_risk"]) for row in risk_rows]
    upper = [float(row["upper_risk_bound"]) for row in risk_rows]
    figure, axis = plt.subplots(figsize=(6.2, 4.0))
    axis.scatter(nfe, risks)
    for name, x_value, y_value in zip(names, nfe, risks, strict=True):
        axis.annotate(name, (x_value, y_value), fontsize=6)
    axis.axhline(alpha, color="black", linestyle="--", linewidth=1)
    axis.set_xlabel("Calibration mean NFE")
    axis.set_ylabel("Empirical strict prompt risk")
    figure.tight_layout()
    figure.savefig(output / "risk_compute.pdf")
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(6.2, 4.0))
    positions = np.arange(len(names))
    axis.errorbar(
        positions,
        risks,
        yerr=[np.zeros(len(names)), np.asarray(upper) - np.asarray(risks)],
        fmt="o",
        capsize=3,
    )
    axis.axhline(
        alpha,
        color="black",
        linestyle="--",
        linewidth=1,
        label=rf"$\alpha={alpha:g}$",
    )
    axis.set_xticks(positions, names, rotation=35, ha="right", fontsize=7)
    axis.set_ylabel("Risk with simultaneous upper bound")
    axis.legend()
    figure.tight_layout()
    figure.savefig(output / "reliability.pdf")
    plt.close(figure)


def _write_failures(
    path: Path,
    records: Mapping[str, Mapping[str, Mapping[str, Sequence[dict[str, Any]]]]],
    methods: Sequence[str],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file_obj:
        writer = csv.DictWriter(
            file_obj,
            fieldnames=("model", "dataset", "sample_id", "method", "category"),
        )
        writer.writeheader()
        for model in _MODELS:
            for dataset in _DATASETS:
                baseline = {
                    str(row["sample_id"]): _is_correct(row)
                    for row in records[model][dataset]["adablock"]
                }
                for method in methods[1:]:
                    for row in records[model][dataset][method]:
                        candidate = _is_correct(row)
                        reference = baseline[str(row["sample_id"])]
                        if candidate == reference:
                            continue
                        writer.writerow(
                            {
                                "model": model,
                                "dataset": dataset,
                                "sample_id": row["sample_id"],
                                "method": method,
                                "category": "regression" if reference else "recovery",
                            }
                        )


def write_rc_pag_report(
    run_dir: str | Path,
    *,
    records: Mapping[str, Mapping[str, Mapping[str, Sequence[dict[str, Any]]]]],
    certificate: Mapping[str, Any],
    bootstrap_samples: int,
    seed: int,
    minimum_accuracy_lower_ci: float = -0.02,
    estimator_manifest: Mapping[str, Any] | None = None,
    screening_summary: Mapping[str, Any] | None = None,
    methods: Sequence[str] = _DEFAULT_METHODS,
    primary_method: str = "rc_pag_history",
    require_history_frontier_ci: bool = True,
    minimum_model_nfe_reduction_lower_ci: float | None = None,
    minimum_model_latency_reduction_lower_ci: float | None = None,
    require_evaluated_row_nonincrease: bool = False,
    require_trajectory_equivalence: bool = False,
) -> dict[str, Any]:
    if bootstrap_samples < 1:
        raise ValueError("bootstrap_samples must be positive")
    methods = tuple(methods)
    if not methods or methods[0] != "adablock" or primary_method not in methods:
        raise ValueError("report methods must start with AdaBlock and include the primary method")
    _validate_coverage(records, methods)
    risk_rows = _risk_rows(certificate)
    summary: dict[str, Any] = {}
    for model_index, model in enumerate(_MODELS):
        summary[model] = {}
        for dataset_index, dataset in enumerate(_DATASETS):
            method_records = records[model][dataset]
            method_summary = {method: _summary(method_records[method]) for method in methods}
            comparisons = {
                f"{method}_vs_adablock": _pair_summary(
                    list(method_records[method]),
                    list(method_records["adablock"]),
                    bootstrap_samples=bootstrap_samples,
                    seed=seed + 100 * model_index + 10 * dataset_index,
                )
                for method in methods[1:]
            }
            summary[model][dataset] = {
                "methods": method_summary,
                "comparisons": comparisons,
            }
    normalized = {}
    for method in methods:
        ratios = [
            summary[model][dataset]["methods"][method]["mean_nfe"]
            / summary[model][dataset]["methods"]["adablock"]["mean_nfe"]
            for model in _MODELS
            for dataset in _IN_DOMAIN
        ]
        normalized[method] = float(np.mean(ratios))
    summary["normalized_cross_model"] = normalized
    audit = _audit(
        summary,
        certificate,
        minimum_accuracy_lower_ci=minimum_accuracy_lower_ci,
        bootstrap_samples=bootstrap_samples,
        seed=seed,
        records=records,
        primary_method=primary_method,
        require_history_frontier_ci=require_history_frontier_ci,
        minimum_model_nfe_reduction_lower_ci=minimum_model_nfe_reduction_lower_ci,
        minimum_model_latency_reduction_lower_ci=(minimum_model_latency_reduction_lower_ci),
        require_evaluated_row_nonincrease=require_evaluated_row_nonincrease,
        require_trajectory_equivalence=require_trajectory_equivalence,
    )
    output = Path(run_dir) / "report"
    figures = output / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    _write_json(output / "summary.json", summary)
    _write_json(output / "claim_audit.json", audit)
    _write_json(output / "risk_diagnostics.json", {"candidates": risk_rows})
    _write_main_table(output / "tables" / "main_results.tex", summary, methods)
    _write_calibration_table(output / "tables" / "calibration.tex", risk_rows)
    _write_ablation_table(output / "tables" / "ablations.tex", summary, methods)
    if estimator_manifest is not None:
        _write_estimator_table(output / "tables" / "estimator_ablation.tex", estimator_manifest)
        if estimator_manifest.get("benefit_models"):
            _write_benefit_table(output / "tables" / "benefit_ablation.tex", estimator_manifest)
    if screening_summary is not None:
        _write_screening_table(output / "tables" / "screening_ablation.tex", screening_summary)
    headline = (
        "RC-PAG satisfied every predeclared claim gate."
        if audit["headline_eligible"]
        else "RC-PAG is not eligible for the positive headline under the predeclared gates."
    )
    (output / "tables" / "headline.tex").write_text(headline + "\n", encoding="utf-8")
    (output / "headline.tex").write_text(headline + "\n", encoding="utf-8")
    _write_figures(
        figures,
        summary,
        risk_rows,
        methods,
        alpha=float(certificate.get("alpha", 0.05)),
    )
    _write_failures(output / "failure_taxonomy.csv", records, methods)
    return audit
