"""PAG generation with reactive block sizing and predictive residual budget.
Block boundaries are determined reactively from logits (AdaBlock-style).
Refinement budget is predicted by the classifier.
Budget enforcement is soft: exit early if tokens are few/confident/stable.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
import torch.nn.functional as F

from pag.experiments.rc_pag_adapter import (
    continue_shadow_refinement,
    observation_from_tensors,
    observe_policy_step,
    serialize_policy_step,
)
from pag.experiments.rc_pag_features import RealizedBlock


def _compute_block_length(
    logits: torch.Tensor,
    predicted_tokens: torch.Tensor,
    prompt: torch.Tensor,
    gen_length: int,
    generated_length: int,
    default_block_length: int,
    *,
    delimiter_ids: list[int],
    delimiter_threshold: float,
) -> int:
    """AdaBlock delimiter rule without importing its heavyweight CLI module."""
    prompt_length = prompt.shape[1]
    block_start = prompt_length + generated_length
    remaining_length = gen_length - generated_length
    window_size = min(int(0.25 * gen_length), remaining_length)
    window_tokens = predicted_tokens[0, block_start : block_start + window_size]
    delimiter_mask = torch.zeros_like(window_tokens, dtype=torch.bool)
    for token_id in delimiter_ids:
        delimiter_mask |= window_tokens == token_id
    if not torch.any(delimiter_mask):
        return min(default_block_length, remaining_length)
    delimiter_pos = block_start + torch.nonzero(delimiter_mask).squeeze(-1)
    delimiter_logits = logits[0, delimiter_pos, predicted_tokens[0, delimiter_pos]]
    log_sum_exp = torch.logsumexp(logits[0, delimiter_pos, :], dim=-1)
    delimiter_confidences = torch.exp(delimiter_logits - log_sum_exp)
    max_confidence, best_index = torch.max(delimiter_confidences, dim=0)
    if max_confidence.item() < delimiter_threshold:
        return min(default_block_length, remaining_length)
    return int(delimiter_pos[best_index].item() - block_start + 1)


def _rc_pag_observation(
    logits: torch.Tensor,
    current_tokens: torch.Tensor,
    *,
    mask_token_id: int,
    step_index: int,
    digit_ids: torch.Tensor | None = None,
    delimiter_ids: torch.Tensor | None = None,
):
    return observation_from_tensors(
        logits=logits,
        current_tokens=current_tokens,
        mask_token_id=mask_token_id,
        step_index=step_index,
        digit_ids=digit_ids,
        delimiter_ids=delimiter_ids,
    )


def _observe_rc_pag_step(
    risk_policy,
    *,
    local_logits: torch.Tensor,
    local_tokens: torch.Tensor,
    mask_id: int,
    step_index: int,
    full_tokens: torch.Tensor,
    block_start: int,
    block_end: int,
    digit_ids_tensor: torch.Tensor | None,
    delimiter_ids_tensor: torch.Tensor | None,
    cache,
    shadow_callback,
    shadow_all_steps: bool,
    records: list[dict[str, object]],
) -> bool:
    step = observe_policy_step(
        risk_policy,
        logits=local_logits,
        current_tokens=local_tokens,
        mask_token_id=mask_id,
        step_index=step_index,
        full_tokens=full_tokens,
        block_start=block_start,
        block_end=block_end,
        digit_ids=digit_ids_tensor,
        delimiter_ids=delimiter_ids_tensor,
        cache=cache,
        shadow_callback=shadow_callback,
        shadow_all_steps=shadow_all_steps,
    )
    if step is None:
        return False
    records.append(serialize_policy_step(step))
    return bool(step.decision.should_stop)


def _record_rc_pag_realized(
    risk_policy,
    *,
    block_length: int,
    nfe: int,
    mean_confidence: float,
    min_confidence: float,
    digit_fraction: float,
    delimiter_fraction: float,
) -> None:
    if risk_policy is None:
        return
    risk_policy.record_realized(
        RealizedBlock(
            block_size=int(block_length),
            nfe=int(nfe),
            mean_confidence=float(mean_confidence),
            min_confidence=float(min_confidence),
            digit_fraction=float(digit_fraction),
            delimiter_fraction=float(delimiter_fraction),
        )
    )


def make_llada_shadow_callback(
    model,
    *,
    mode: str,
    mask_id: int,
    threshold: float,
    max_steps: int,
):
    """Create an on-policy shadow continuation for uncached or dual-cache LLaDA."""
    if mode not in {"uncached", "dual_cache"}:
        raise ValueError("LLaDA shadow mode must be uncached or dual_cache")

    def callback(request):
        def forward(tokens, cache, block_start, block_end):
            if mode == "uncached":
                output = model(tokens)
                return output.logits[:, block_start:block_end, :], None
            replace_position = torch.zeros_like(tokens, dtype=torch.bool)
            replace_position[:, block_start:block_end] = True
            output = model(
                tokens[:, block_start:block_end],
                past_key_values=cache,
                use_cache=True,
                replace_position=replace_position,
            )
            return output.logits, cache

        return continue_shadow_refinement(
            request,
            forward=forward,
            mask_token_id=mask_id,
            threshold=threshold,
            max_steps=max_steps,
        ).tokens

    return callback


def add_gumbel_noise(logits: torch.Tensor, temperature: float) -> torch.Tensor:
    if temperature == 0:
        return logits
    logits = logits.to(torch.float64)
    noise = torch.rand_like(logits, dtype=torch.float64)
    gumbel_noise = (-torch.log(noise)) ** temperature
    return logits.exp() / gumbel_noise


def get_transfer_index(
    logits: torch.Tensor,
    predicted_tokens: torch.Tensor,
    remasking: str,
    mask_index: torch.Tensor,
    x: torch.Tensor,
    num_transfer_tokens,
    threshold: float | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    x0 = predicted_tokens
    if remasking == "low_confidence":
        probs = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(probs, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1)
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64)
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(torch.finfo(x0_p.dtype).min, device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf)
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        max_conf_indices = torch.argmax(confidence, dim=1, keepdim=True)
        force_mask = torch.zeros_like(transfer_index).scatter_(1, max_conf_indices, True)
        transfer_index = (transfer_index | force_mask) & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        msg = "num_transfer_tokens must be a tensor when threshold is None."
        raise ValueError(msg)
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    _, idx = torch.sort(confidence, dim=1, descending=True)
    batch_size, seq_len = confidence.shape
    cols = torch.arange(seq_len, device=confidence.device).unsqueeze(0).expand(batch_size, seq_len)
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(batch_size, seq_len)
    select_sorted = cols < k_expanded
    transfer_int = torch.zeros(batch_size, seq_len, device=confidence.device, dtype=torch.int8)
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index
    return x0, transfer_index


def _force_commit(
    predicted_tokens: torch.Tensor,
    mask_index: torch.Tensor,
    x: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    x0 = torch.where(mask_index, predicted_tokens, x)
    return x0, mask_index


@dataclass(frozen=True, slots=True)
class EnforcementDecision:
    force_commit: bool
    reason: str | None


def decide_budget_enforcement(
    *,
    mode: str,
    nfe: int,
    budget: int,
    max_steps: int,
    confident: bool,
    stable: bool,
    complete: bool,
) -> EnforcementDecision:
    if mode not in {"soft_gate", "hard_cap"}:
        raise ValueError(f"Unsupported enforcement mode: {mode}")
    if complete:
        return EnforcementDecision(False, "complete")
    if nfe >= max_steps:
        return EnforcementDecision(True, "hard_max")
    if nfe < budget:
        return EnforcementDecision(False, None)
    if mode == "hard_cap":
        return EnforcementDecision(True, "hard_budget")
    if confident:
        return EnforcementDecision(True, "confidence_gate")
    if stable:
        return EnforcementDecision(True, "stability_gate")
    return EnforcementDecision(False, None)


def _initial_enforcement_decision(
    *,
    x: torch.Tensor,
    block_start: int,
    block_end: int,
    mask_id: int,
    initial_max_probs: torch.Tensor,
    mode: str,
    budget: int,
    max_steps: int,
    tau_commit: float,
) -> EnforcementDecision:
    remaining = x[:, block_start:block_end] == mask_id
    complete = not bool(remaining.any())
    confidences = initial_max_probs[remaining]
    confident = bool(confidences.numel()) and confidences.min().item() >= tau_commit
    return decide_budget_enforcement(
        mode=mode,
        nfe=1,
        budget=budget,
        max_steps=max_steps,
        confident=confident,
        stable=False,
        complete=complete,
    )


def _record_schedule(
    schedule_history: list[dict[str, object]],
    *,
    schedule,
    nfe: int,
    block_start: int,
    block_end: int,
    exit_reason: str,
    risk_steps: list[dict[str, object]] | None = None,
    final_tokens: torch.Tensor | None = None,
) -> None:
    record = {
            "block_index": len(schedule_history),
            "predicted_tuple": {
                "block_size": int(schedule.predicted_tuple.block_size),
                "refinement_steps": int(schedule.predicted_tuple.refinement_steps),
            },
            "applied_block_size": int(schedule.applied_block_size),
            "budgeted_refinement_steps": int(schedule.budgeted_refinement_steps),
            "actual_nfe_used": int(nfe),
            "block_start": int(block_start),
            "block_end": int(block_end),
            "exit_reason": exit_reason,
        }
    if risk_steps:
        record["risk_steps"] = risk_steps
        record["final_tokens"] = (
            final_tokens.detach().cpu().reshape(-1).tolist() if final_tokens is not None else []
        )
        record["shadow_losses"] = [
            row["shadow_loss"] for row in risk_steps if row.get("shadow_loss") is not None
        ]
    schedule_history.append(record)


@torch.no_grad()
def generate_pag(
    model,
    prompt: torch.Tensor,
    scheduler,
    *,
    steps: int = 128,
    gen_length: int = 128,
    temperature: float = 0.0,
    remasking: str = "low_confidence",
    mask_id: int = 126336,
    threshold: float | None = None,
    max_block_length: int | None = None,
    max_refinement_steps: int | None = None,
    digit_ids_tensor: torch.Tensor | None = None,
    delimiter_ids_tensor: torch.Tensor | None = None,
    delimiter_ids: list[int] | None = None,
    delimiter_threshold: float | None = None,
    tau_commit: float = 0.80,
    tau_stable_steps: int = 2,
    default_block_length: int = 32,
    enforcement_mode: str = "soft_gate",
    risk_policy=None,
    shadow_callback=None,
    shadow_all_steps: bool = False,
):
    assert prompt.shape[0] == 1, "Batch size > 1 is not supported"
    assert threshold is not None
    decide_budget_enforcement(
        mode=enforcement_mode,
        nfe=0,
        budget=1,
        max_steps=1,
        confident=False,
        stable=False,
        complete=True,
    )
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(
        model.device
    )
    x[:, : prompt.shape[1]] = prompt.clone()
    scheduler.reset()
    if risk_policy is not None:
        risk_policy.reset_prompt()
    max_block_length = gen_length if max_block_length is None else int(max_block_length)
    max_refinement_steps = steps if max_refinement_steps is None else int(max_refinement_steps)
    delimiter_ids = delimiter_ids or [198]

    generated_length = 0
    nfe_history: list[int] = []
    block_history: list[int] = []
    schedule_history: list[dict[str, object]] = []

    while generated_length < gen_length:
        output = model(x)
        logits = output.logits
        logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
        predicted_tokens = torch.argmax(logits_with_noise, dim=-1)

        block_length = _compute_block_length(
            logits,
            predicted_tokens,
            prompt,
            gen_length,
            generated_length,
            default_block_length=default_block_length,
            delimiter_ids=delimiter_ids,
            delimiter_threshold=delimiter_threshold or float("inf"),
        )
        block_length = min(int(block_length), max_block_length, gen_length - generated_length)

        schedule = scheduler.next_schedule(
            block_size=block_length,
            remaining_tokens=gen_length - generated_length,
            max_block_length=max_block_length,
            max_refinement_steps=max_refinement_steps,
        )
        block_start = prompt.shape[1] + generated_length
        block_end = block_start + block_length
        generated_length += block_length
        risk_steps: list[dict[str, object]] = []
        if risk_policy is not None:
            risk_policy.start_block()

        unmask_confs: list[torch.Tensor] = []
        mask_index = x == mask_id
        mask_index[:, block_end:] = 0
        risk_force_commit = _observe_rc_pag_step(
            risk_policy,
            local_logits=logits[:, block_start:block_end, :],
            local_tokens=x[:, block_start:block_end],
            mask_id=mask_id,
            step_index=1,
            full_tokens=x,
            block_start=block_start,
            block_end=block_end,
            digit_ids_tensor=digit_ids_tensor,
            delimiter_ids_tensor=delimiter_ids_tensor,
            cache=None,
            shadow_callback=shadow_callback,
            shadow_all_steps=shadow_all_steps,
            records=risk_steps,
        )
        x0, transfer_index = get_transfer_index(
            logits,
            predicted_tokens,
            remasking,
            mask_index,
            x,
            None,
            threshold,
        )
        initial_probs = F.softmax(logits[:, block_start:block_end, :], dim=-1)
        initial_max_probs = initial_probs.max(dim=-1).values
        newly_unmasked = transfer_index[:, block_start:block_end]
        if newly_unmasked.any():
            unmask_confs.append(initial_max_probs[newly_unmasked])
        x[transfer_index] = x0[transfer_index]

        # Count every model invocation, including the boundary/proposal pass above.
        nfe = 1
        exit_reason: str | None = None
        prev_predictions: list[torch.Tensor] = []
        initial_decision = _initial_enforcement_decision(
            x=x,
            block_start=block_start,
            block_end=block_end,
            mask_id=mask_id,
            initial_max_probs=initial_max_probs,
            mode=enforcement_mode,
            budget=schedule.budgeted_refinement_steps,
            max_steps=max_refinement_steps,
            tau_commit=tau_commit,
        )
        if risk_force_commit:
            initial_decision = EnforcementDecision(True, "risk_policy")
        if initial_decision.force_commit:
            mask_index = x == mask_id
            mask_index[:, block_end:] = 0
            x0, transfer_index = _force_commit(predicted_tokens, mask_index, x)
            x[transfer_index] = x0[transfer_index]
            exit_reason = initial_decision.reason

        while True:
            if (x[:, block_start:block_end] == mask_id).sum() == 0:
                exit_reason = exit_reason or "complete"
                break
            if nfe >= max_refinement_steps:
                mask_index = x == mask_id
                mask_index[:, block_end:] = 0
                x0, transfer_index = _force_commit(predicted_tokens, mask_index, x)
                x[transfer_index] = x0[transfer_index]
                exit_reason = "hard_max"
                break
            output = model(x)
            logits = output.logits
            logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
            predicted_tokens = torch.argmax(logits_with_noise, dim=-1)
            nfe += 1
            mask_index = x == mask_id
            mask_index[:, block_end:] = 0
            block_probs = F.softmax(logits[:, block_start:block_end, :], dim=-1)
            block_max_probs = block_probs.max(dim=-1).values
            risk_force_commit = _observe_rc_pag_step(
                risk_policy,
                local_logits=logits[:, block_start:block_end, :],
                local_tokens=x[:, block_start:block_end],
                mask_id=mask_id,
                step_index=nfe,
                full_tokens=x,
                block_start=block_start,
                block_end=block_end,
                digit_ids_tensor=digit_ids_tensor,
                delimiter_ids_tensor=delimiter_ids_tensor,
                cache=None,
                shadow_callback=shadow_callback,
                shadow_all_steps=shadow_all_steps,
                records=risk_steps,
            )
            if risk_force_commit:
                x0, transfer_index = _force_commit(predicted_tokens, mask_index, x)
                x[transfer_index] = x0[transfer_index]
                exit_reason = "risk_policy"
                break

            if nfe >= schedule.budgeted_refinement_steps:
                block_mask = x[:, block_start:block_end] == mask_id
                remaining_count = block_mask.sum().item()
                few_remaining = remaining_count <= max(1, math.ceil(0.10 * block_length))
                confident = False
                if remaining_count > 0:
                    remaining_logits = logits[:, block_start:block_end][block_mask]
                    remaining_confs = torch.softmax(remaining_logits, dim=-1).max(dim=-1).values
                    confident = remaining_confs.min().item() >= tau_commit
                else:
                    confident = True
                stable = False
                if remaining_count > 0 and len(prev_predictions) >= tau_stable_steps:
                    current_for_remaining = predicted_tokens[:, block_start:block_end][block_mask]
                    stable = all(
                        torch.all(current_for_remaining == p[block_mask])
                        for p in prev_predictions[-tau_stable_steps:]
                    )
                elif remaining_count == 0:
                    stable = True
                decision = decide_budget_enforcement(
                    mode=enforcement_mode,
                    nfe=nfe,
                    budget=schedule.budgeted_refinement_steps,
                    max_steps=max_refinement_steps,
                    confident=confident or (few_remaining and confident),
                    stable=stable,
                    complete=False,
                )
                if decision.force_commit:
                    x0, transfer_index = _force_commit(predicted_tokens, mask_index, x)
                    x[transfer_index] = x0[transfer_index]
                    exit_reason = decision.reason
                    break
                x0, transfer_index = get_transfer_index(
                    logits,
                    predicted_tokens,
                    remasking,
                    mask_index,
                    x,
                    None,
                    threshold,
                )
            else:
                x0, transfer_index = get_transfer_index(
                    logits,
                    predicted_tokens,
                    remasking,
                    mask_index,
                    x,
                    None,
                    threshold,
                )

            newly_unmasked = transfer_index[:, block_start:block_end]
            if newly_unmasked.any():
                unmask_confs.append(block_max_probs[newly_unmasked])
            x[transfer_index] = x0[transfer_index]
            prev_predictions.append(predicted_tokens[:, block_start:block_end].clone())
            prev_predictions = prev_predictions[-tau_stable_steps:]
            if nfe >= max_refinement_steps and exit_reason is None:
                exit_reason = "hard_max"

        if unmask_confs:
            all_confs = torch.cat(unmask_confs)
            mean_conf = all_confs.mean().item()
            min_conf = all_confs.min().item()
        else:
            mean_conf = min_conf = 1.0
        block_tokens = x[0, block_start:block_end]
        digit_frac = (
            torch.isin(block_tokens, digit_ids_tensor.to(x.device)).float().mean().item()
            if digit_ids_tensor is not None
            else 0.0
        )
        delim_frac = (
            torch.isin(block_tokens, delimiter_ids_tensor.to(x.device)).float().mean().item()
            if delimiter_ids_tensor is not None
            else 0.0
        )
        scheduler.record_realized(block_length, nfe, mean_conf, min_conf, digit_frac, delim_frac)
        _record_rc_pag_realized(
            risk_policy,
            block_length=block_length,
            nfe=nfe,
            mean_confidence=mean_conf,
            min_confidence=min_conf,
            digit_fraction=digit_frac,
            delimiter_fraction=delim_frac,
        )
        nfe_history.append(nfe)
        block_history.append(block_length)
        _record_schedule(
            schedule_history,
            schedule=schedule,
            nfe=nfe,
            block_start=block_start,
            block_end=block_end,
            exit_reason=exit_reason or "complete",
            risk_steps=risk_steps,
            final_tokens=block_tokens,
        )

    return x, nfe_history, block_history, schedule_history


@torch.no_grad()
def generate_pag_prefix_cache(
    model,
    prompt: torch.Tensor,
    scheduler,
    *,
    steps: int = 128,
    gen_length: int = 128,
    temperature: float = 0.0,
    remasking: str = "low_confidence",
    mask_id: int = 126336,
    threshold: float | None = None,
    max_block_length: int | None = None,
    max_refinement_steps: int | None = None,
    digit_ids_tensor: torch.Tensor | None = None,
    delimiter_ids_tensor: torch.Tensor | None = None,
    delimiter_ids: list[int] | None = None,
    delimiter_threshold: float | None = None,
    tau_commit: float = 0.80,
    tau_stable_steps: int = 2,
    default_block_length: int = 32,
    enforcement_mode: str = "soft_gate",
    risk_policy=None,
    shadow_callback=None,
    shadow_all_steps: bool = False,
):
    assert prompt.shape[0] == 1, "Batch size > 1 is not supported"
    assert threshold is not None
    decide_budget_enforcement(
        mode=enforcement_mode,
        nfe=0,
        budget=1,
        max_steps=1,
        confident=False,
        stable=False,
        complete=True,
    )
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(
        model.device
    )
    x[:, : prompt.shape[1]] = prompt.clone()
    scheduler.reset()
    if risk_policy is not None:
        risk_policy.reset_prompt()
    max_block_length = gen_length if max_block_length is None else int(max_block_length)
    max_refinement_steps = steps if max_refinement_steps is None else int(max_refinement_steps)
    delimiter_ids = delimiter_ids or [198]

    generated_length = 0
    nfe_history: list[int] = []
    block_history: list[int] = []
    schedule_history: list[dict[str, object]] = []

    while generated_length < gen_length:
        output = model(x, use_cache=True)
        full_cache = output.past_key_values
        logits = output.logits
        logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
        predicted_tokens = torch.argmax(logits_with_noise, dim=-1)

        block_length = _compute_block_length(
            logits,
            predicted_tokens,
            prompt,
            gen_length,
            generated_length,
            default_block_length=default_block_length,
            delimiter_ids=delimiter_ids,
            delimiter_threshold=delimiter_threshold or float("inf"),
        )
        block_length = min(int(block_length), max_block_length, gen_length - generated_length)

        schedule = scheduler.next_schedule(
            block_size=block_length,
            remaining_tokens=gen_length - generated_length,
            max_block_length=max_block_length,
            max_refinement_steps=max_refinement_steps,
        )
        block_start = prompt.shape[1] + generated_length
        block_end = block_start + block_length
        generated_length += block_length
        risk_steps: list[dict[str, object]] = []
        if risk_policy is not None:
            risk_policy.start_block()

        unmask_confs: list[torch.Tensor] = []
        mask_index = x == mask_id
        mask_index[:, block_end:] = 0
        risk_force_commit = _observe_rc_pag_step(
            risk_policy,
            local_logits=logits[:, block_start:block_end, :],
            local_tokens=x[:, block_start:block_end],
            mask_id=mask_id,
            step_index=1,
            full_tokens=x,
            block_start=block_start,
            block_end=block_end,
            digit_ids_tensor=digit_ids_tensor,
            delimiter_ids_tensor=delimiter_ids_tensor,
            cache=full_cache,
            shadow_callback=shadow_callback,
            shadow_all_steps=shadow_all_steps,
            records=risk_steps,
        )
        x0, transfer_index = get_transfer_index(
            logits,
            predicted_tokens,
            remasking,
            mask_index,
            x,
            None,
            threshold,
        )
        initial_probs = F.softmax(logits[:, block_start:block_end, :], dim=-1)
        initial_max_probs = initial_probs.max(dim=-1).values
        newly_unmasked = transfer_index[:, block_start:block_end]
        if newly_unmasked.any():
            unmask_confs.append(initial_max_probs[newly_unmasked])
        x[transfer_index] = x0[transfer_index]

        prefix_cache = []
        for cache_layer in full_cache:
            prefix_cache.append(())
            for cache_entry in cache_layer:
                prefix_cache[-1] += (cache_entry[:, :, :block_start],)

        nfe = 1
        exit_reason: str | None = None
        prev_predictions: list[torch.Tensor] = []
        initial_decision = _initial_enforcement_decision(
            x=x,
            block_start=block_start,
            block_end=block_end,
            mask_id=mask_id,
            initial_max_probs=initial_max_probs,
            mode=enforcement_mode,
            budget=schedule.budgeted_refinement_steps,
            max_steps=max_refinement_steps,
            tau_commit=tau_commit,
        )
        if risk_force_commit:
            initial_decision = EnforcementDecision(True, "risk_policy")
        if initial_decision.force_commit:
            mask_index = x[:, block_start:] == mask_id
            mask_index[:, block_length:] = 0
            local_predictions = predicted_tokens[:, block_start:]
            x0, transfer_index = _force_commit(local_predictions, mask_index, x[:, block_start:])
            x[:, block_start:][transfer_index] = x0[transfer_index]
            exit_reason = initial_decision.reason

        while True:
            if (x[:, block_start:block_end] == mask_id).sum() == 0:
                exit_reason = exit_reason or "complete"
                break
            if nfe >= max_refinement_steps:
                mask_index = x[:, block_start:] == mask_id
                mask_index[:, block_length:] = 0
                local_predictions = predicted_tokens[:, block_start:]
                x0, transfer_index = _force_commit(
                    local_predictions, mask_index, x[:, block_start:]
                )
                x[:, block_start:][transfer_index] = x0[transfer_index]
                exit_reason = "hard_max"
                break

            mask_index = x[:, block_start:] == mask_id
            mask_index[:, block_length:] = 0
            block_output = model(x[:, block_start:], past_key_values=prefix_cache, use_cache=True)
            block_logits = block_output.logits
            block_logits_with_noise = add_gumbel_noise(block_logits, temperature=temperature)
            block_predicted_tokens = torch.argmax(block_logits_with_noise, dim=-1)
            nfe += 1

            block_probs = F.softmax(block_logits, dim=-1)
            block_max_probs = block_probs.max(dim=-1).values
            risk_force_commit = _observe_rc_pag_step(
                risk_policy,
                local_logits=block_logits[:, :block_length, :],
                local_tokens=x[:, block_start:block_end],
                mask_id=mask_id,
                step_index=nfe,
                full_tokens=x,
                block_start=block_start,
                block_end=block_end,
                digit_ids_tensor=digit_ids_tensor,
                delimiter_ids_tensor=delimiter_ids_tensor,
                cache=prefix_cache,
                shadow_callback=shadow_callback,
                shadow_all_steps=shadow_all_steps,
                records=risk_steps,
            )
            if risk_force_commit:
                x0, transfer_index = _force_commit(
                    block_predicted_tokens, mask_index, x[:, block_start:]
                )
                x[:, block_start:][transfer_index] = x0[transfer_index]
                exit_reason = "risk_policy"
                break

            if nfe >= schedule.budgeted_refinement_steps:
                block_mask = x[:, block_start:block_end] == mask_id
                remaining_count = block_mask.sum().item()
                few_remaining = remaining_count <= max(1, math.ceil(0.10 * block_length))
                confident = False
                if remaining_count > 0:
                    local_conf = block_max_probs[0, :block_length][block_mask[0, :block_length]]
                    confident = (
                        local_conf.min().item() >= tau_commit if local_conf.numel() > 0 else True
                    )
                else:
                    confident = True
                stable = False
                if remaining_count > 0 and len(prev_predictions) >= tau_stable_steps:
                    current_for_remaining = block_predicted_tokens[0, :block_length][
                        block_mask[0, :block_length]
                    ]
                    stable = all(
                        torch.all(current_for_remaining == p[block_mask[0, :block_length]])
                        for p in prev_predictions[-tau_stable_steps:]
                    )
                elif remaining_count == 0:
                    stable = True
                decision = decide_budget_enforcement(
                    mode=enforcement_mode,
                    nfe=nfe,
                    budget=schedule.budgeted_refinement_steps,
                    max_steps=max_refinement_steps,
                    confident=confident or (few_remaining and confident),
                    stable=stable,
                    complete=False,
                )
                if decision.force_commit:
                    x0, transfer_index = _force_commit(
                        block_predicted_tokens, mask_index, x[:, block_start:]
                    )
                    x[:, block_start:][transfer_index] = x0[transfer_index]
                    exit_reason = decision.reason
                    break
                x0, transfer_index = get_transfer_index(
                    block_logits,
                    block_predicted_tokens,
                    remasking,
                    mask_index,
                    x[:, block_start:],
                    None,
                    threshold,
                )
            else:
                x0, transfer_index = get_transfer_index(
                    block_logits,
                    block_predicted_tokens,
                    remasking,
                    mask_index,
                    x[:, block_start:],
                    None,
                    threshold,
                )

            newly_unmasked = transfer_index[:, :block_length]
            if newly_unmasked.any():
                unmask_confs.append(block_max_probs[0, :block_length][newly_unmasked[0]])
            x[:, block_start:][transfer_index] = x0[transfer_index]
            prev_predictions.append(block_predicted_tokens[0, :block_length].clone())
            prev_predictions = prev_predictions[-tau_stable_steps:]

        if unmask_confs:
            all_confs = torch.cat(unmask_confs)
            mean_conf = all_confs.mean().item()
            min_conf = all_confs.min().item()
        else:
            mean_conf = min_conf = 1.0
        block_tokens = x[0, block_start:block_end]
        digit_frac = (
            torch.isin(block_tokens, digit_ids_tensor.to(x.device)).float().mean().item()
            if digit_ids_tensor is not None
            else 0.0
        )
        delim_frac = (
            torch.isin(block_tokens, delimiter_ids_tensor.to(x.device)).float().mean().item()
            if delimiter_ids_tensor is not None
            else 0.0
        )
        scheduler.record_realized(block_length, nfe, mean_conf, min_conf, digit_frac, delim_frac)
        _record_rc_pag_realized(
            risk_policy,
            block_length=block_length,
            nfe=nfe,
            mean_confidence=mean_conf,
            min_confidence=min_conf,
            digit_fraction=digit_frac,
            delimiter_fraction=delim_frac,
        )
        nfe_history.append(nfe)
        block_history.append(block_length)
        _record_schedule(
            schedule_history,
            schedule=schedule,
            nfe=nfe,
            block_start=block_start,
            block_end=block_end,
            exit_reason=exit_reason or "complete",
            risk_steps=risk_steps,
            final_tokens=block_tokens,
        )

    return x, nfe_history, block_history, schedule_history


@torch.no_grad()
def generate_pag_dual_cache(
    model,
    prompt: torch.Tensor,
    scheduler,
    *,
    steps: int = 128,
    gen_length: int = 128,
    temperature: float = 0.0,
    remasking: str = "low_confidence",
    mask_id: int = 126336,
    threshold: float | None = None,
    max_block_length: int | None = None,
    max_refinement_steps: int | None = None,
    digit_ids_tensor: torch.Tensor | None = None,
    delimiter_ids_tensor: torch.Tensor | None = None,
    delimiter_ids: list[int] | None = None,
    delimiter_threshold: float | None = None,
    tau_commit: float = 0.80,
    tau_stable_steps: int = 2,
    default_block_length: int = 32,
    enforcement_mode: str = "soft_gate",
    risk_policy=None,
    shadow_callback=None,
    shadow_all_steps: bool = False,
):
    assert prompt.shape[0] == 1, "Batch size > 1 is not supported"
    assert threshold is not None
    decide_budget_enforcement(
        mode=enforcement_mode,
        nfe=0,
        budget=1,
        max_steps=1,
        confident=False,
        stable=False,
        complete=True,
    )
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(
        model.device
    )
    x[:, : prompt.shape[1]] = prompt.clone()
    scheduler.reset()
    if risk_policy is not None:
        risk_policy.reset_prompt()
    max_block_length = gen_length if max_block_length is None else int(max_block_length)
    max_refinement_steps = steps if max_refinement_steps is None else int(max_refinement_steps)
    delimiter_ids = delimiter_ids or [198]

    generated_length = 0
    nfe_history: list[int] = []
    block_history: list[int] = []
    schedule_history: list[dict[str, object]] = []

    while generated_length < gen_length:
        output = model(x, use_cache=True)
        full_cache = output.past_key_values
        logits = output.logits
        logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
        predicted_tokens = torch.argmax(logits_with_noise, dim=-1)

        block_length = _compute_block_length(
            logits,
            predicted_tokens,
            prompt,
            gen_length,
            generated_length,
            default_block_length=default_block_length,
            delimiter_ids=delimiter_ids,
            delimiter_threshold=delimiter_threshold or float("inf"),
        )
        block_length = min(int(block_length), max_block_length, gen_length - generated_length)

        schedule = scheduler.next_schedule(
            block_size=block_length,
            remaining_tokens=gen_length - generated_length,
            max_block_length=max_block_length,
            max_refinement_steps=max_refinement_steps,
        )

        block_start = prompt.shape[1] + generated_length
        block_end = block_start + block_length
        generated_length += block_length
        risk_steps: list[dict[str, object]] = []
        if risk_policy is not None:
            risk_policy.start_block()

        # First unmask
        unmask_confs: list[torch.Tensor] = []
        mask_index = x == mask_id
        mask_index[:, block_end:] = 0
        risk_force_commit = _observe_rc_pag_step(
            risk_policy,
            local_logits=logits[:, block_start:block_end, :],
            local_tokens=x[:, block_start:block_end],
            mask_id=mask_id,
            step_index=1,
            full_tokens=x,
            block_start=block_start,
            block_end=block_end,
            digit_ids_tensor=digit_ids_tensor,
            delimiter_ids_tensor=delimiter_ids_tensor,
            cache=full_cache,
            shadow_callback=shadow_callback,
            shadow_all_steps=shadow_all_steps,
            records=risk_steps,
        )
        x0, transfer_index = get_transfer_index(
            logits,
            predicted_tokens,
            remasking,
            mask_index,
            x,
            None,
            threshold,
        )
        initial_probs = F.softmax(logits[:, block_start:block_end, :], dim=-1)
        initial_max_probs = initial_probs.max(dim=-1).values
        newly_unmasked = transfer_index[:, block_start:block_end]
        if newly_unmasked.any():
            unmask_confs.append(initial_max_probs[newly_unmasked])
        x[transfer_index] = x0[transfer_index]

        replace_position = torch.zeros_like(x, dtype=torch.bool)
        replace_position[:, block_start:block_end] = 1

        # Refinement loop with dual cache
        nfe = 1
        exit_reason: str | None = None
        prev_predictions: list[torch.Tensor] = []
        initial_decision = _initial_enforcement_decision(
            x=x,
            block_start=block_start,
            block_end=block_end,
            mask_id=mask_id,
            initial_max_probs=initial_max_probs,
            mode=enforcement_mode,
            budget=schedule.budgeted_refinement_steps,
            max_steps=max_refinement_steps,
            tau_commit=tau_commit,
        )
        if risk_force_commit:
            initial_decision = EnforcementDecision(True, "risk_policy")
        if initial_decision.force_commit:
            mask_index = x[:, block_start:block_end] == mask_id
            local_predictions = predicted_tokens[:, block_start:block_end]
            x0, transfer_index = _force_commit(
                local_predictions, mask_index, x[:, block_start:block_end]
            )
            x[:, block_start:block_end][transfer_index] = x0[transfer_index]
            exit_reason = initial_decision.reason

        while True:
            if (x[:, block_start:block_end] == mask_id).sum() == 0:
                exit_reason = exit_reason or "complete"
                break
            if nfe >= max_refinement_steps:
                mask_index = x[:, block_start:block_end] == mask_id
                local_predictions = predicted_tokens[:, block_start:block_end]
                x0, transfer_index = _force_commit(
                    local_predictions, mask_index, x[:, block_start:block_end]
                )
                x[:, block_start:block_end][transfer_index] = x0[transfer_index]
                exit_reason = "hard_max"
                break

            mask_index = x[:, block_start:block_end] == mask_id
            block_output = model(
                x[:, block_start:block_end],
                past_key_values=full_cache,
                use_cache=True,
                replace_position=replace_position,
            )
            block_logits = block_output.logits
            block_logits_with_noise = add_gumbel_noise(block_logits, temperature=temperature)
            block_predicted_tokens = torch.argmax(block_logits_with_noise, dim=-1)
            nfe += 1

            block_probs = F.softmax(block_logits, dim=-1)
            block_max_probs = block_probs.max(dim=-1).values
            risk_force_commit = _observe_rc_pag_step(
                risk_policy,
                local_logits=block_logits,
                local_tokens=x[:, block_start:block_end],
                mask_id=mask_id,
                step_index=nfe,
                full_tokens=x,
                block_start=block_start,
                block_end=block_end,
                digit_ids_tensor=digit_ids_tensor,
                delimiter_ids_tensor=delimiter_ids_tensor,
                cache=full_cache,
                shadow_callback=shadow_callback,
                shadow_all_steps=shadow_all_steps,
                records=risk_steps,
            )
            if risk_force_commit:
                x0, transfer_index = _force_commit(
                    block_predicted_tokens, mask_index, x[:, block_start:block_end]
                )
                x[:, block_start:block_end][transfer_index] = x0[transfer_index]
                exit_reason = "risk_policy"
                break

            if nfe >= schedule.budgeted_refinement_steps:
                remaining_count = (x[:, block_start:block_end] == mask_id).sum().item()
                few_remaining = remaining_count <= max(1, math.ceil(0.10 * block_length))
                confident = False
                if remaining_count > 0:
                    local_conf = block_max_probs[0, mask_index[0]]
                    confident = (
                        local_conf.min().item() >= tau_commit if local_conf.numel() > 0 else True
                    )
                else:
                    confident = True
                stable = False
                if remaining_count > 0 and len(prev_predictions) >= tau_stable_steps:
                    current_for_remaining = block_predicted_tokens[0][mask_index[0]]
                    stable = all(
                        torch.all(current_for_remaining == p[mask_index[0]])
                        for p in prev_predictions[-tau_stable_steps:]
                    )
                elif remaining_count == 0:
                    stable = True
                decision = decide_budget_enforcement(
                    mode=enforcement_mode,
                    nfe=nfe,
                    budget=schedule.budgeted_refinement_steps,
                    max_steps=max_refinement_steps,
                    confident=confident or (few_remaining and confident),
                    stable=stable,
                    complete=False,
                )
                if decision.force_commit:
                    x0, transfer_index = _force_commit(
                        block_predicted_tokens, mask_index, x[:, block_start:block_end]
                    )
                    x[:, block_start:block_end][transfer_index] = x0[transfer_index]
                    exit_reason = decision.reason
                    break
                x0, transfer_index = get_transfer_index(
                    block_logits,
                    block_predicted_tokens,
                    remasking,
                    mask_index,
                    x[:, block_start:block_end],
                    None,
                    threshold,
                )
            else:
                x0, transfer_index = get_transfer_index(
                    block_logits,
                    block_predicted_tokens,
                    remasking,
                    mask_index,
                    x[:, block_start:block_end],
                    None,
                    threshold,
                )

            newly_unmasked = transfer_index
            if newly_unmasked.any():
                unmask_confs.append(block_max_probs[newly_unmasked])
            x[:, block_start:block_end][transfer_index] = x0[transfer_index]
            prev_predictions.append(block_predicted_tokens[0].clone())
            prev_predictions = prev_predictions[-tau_stable_steps:]

        if unmask_confs:
            all_confs = torch.cat(unmask_confs)
            mean_conf = all_confs.mean().item()
            min_conf = all_confs.min().item()
        else:
            mean_conf = min_conf = 1.0
        block_tokens = x[0, block_start:block_end]
        digit_frac = (
            torch.isin(block_tokens, digit_ids_tensor.to(x.device)).float().mean().item()
            if digit_ids_tensor is not None
            else 0.0
        )
        delim_frac = (
            torch.isin(block_tokens, delimiter_ids_tensor.to(x.device)).float().mean().item()
            if delimiter_ids_tensor is not None
            else 0.0
        )
        scheduler.record_realized(block_length, nfe, mean_conf, min_conf, digit_frac, delim_frac)
        _record_rc_pag_realized(
            risk_policy,
            block_length=block_length,
            nfe=nfe,
            mean_confidence=mean_conf,
            min_confidence=min_conf,
            digit_fraction=digit_frac,
            delimiter_fraction=delim_frac,
        )
        nfe_history.append(nfe)
        block_history.append(block_length)
        _record_schedule(
            schedule_history,
            schedule=schedule,
            nfe=nfe,
            block_start=block_start,
            block_end=block_end,
            exit_reason=exit_reason or "complete",
            risk_steps=risk_steps,
            final_tokens=block_tokens,
        )

    return x, nfe_history, block_history, schedule_history
